 $(document).ready(function() {

     $(document).on("click", "#Cancel", function() {

         $(".btn-primary").hide();
         $(".updateDetails .btn-danger").show();

     });
     $(document).on("click", "#SaveAboutMe", function() {

         $(".btn-primary").hide();
         $(".updateDetails .btn-danger").show();
         alert("data saved successfully")

     });
     $(".updateDetails .btn-danger").on("click", function() {
         $(".btn-danger").hide();
         $(".updateDetails").append("<a id='SaveAboutMe' class='btn btn-primary'>Save</a><a id='Cancel' class='btn btn-primary'>Cancel</a>");
     });

     $('#tableData').on('click', '.delete', function() {
         $(this).parents('tr').remove();
     });

     $(document).on("click", "#tableData .editDeleteButton .edit", function() {

         $(this).parents('.editDeleteButton').find('.delete').hide();
         $(this).parents('.editDeleteButton').find('.edit').hide();

         $(this).parents('.editDeleteButton').append("<button  class='btn btn-primary save'>Save</button><button  class='btn btn-primary cancelButton'>Cancel</button>");

     });

     $(document).on("click", ".cancelButton", function() {
         $(this).parents('.editDeleteButton').find('.save').hide();
         $(this).parents('.editDeleteButton').find('.cancelButton').hide();
         $(this).parents('.editDeleteButton').find('.edit').show();
         $(this).parents('.editDeleteButton').find('.delete').show();

     });
     $(document).on("click", ".save", function() {
         $(this).parents('.editDeleteButton').find('.save').hide();
         $(this).parents('.editDeleteButton').find('.cancelButton').hide();
         $(this).parents('.editDeleteButton').find('.edit').show();
         $(this).parents('.editDeleteButton').find('.delete').show();
         alert("data saved successfully");

     });
     if (!navigator.onLine) {
         document.getElementById('collegeMap').src='assets/img/college-map.jpg';
     }

 });