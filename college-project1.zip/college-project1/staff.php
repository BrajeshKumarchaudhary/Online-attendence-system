<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
    <link rel="stylesheet" type="text/css" href="assets/lib/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\font-awesome.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\moonicon.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\build.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/lib/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="assets/lib/css/jquery-ui.css">

</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <img src="assets/img/logo.png" class="img-responsive" alt="logo">
                </div>
            </div>
        </div>
    </header>
    <div class="navigation-bar">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <ul>
                        
                            <li ><a href="index.php">Home</a></li>
                       
                       
                            <li > <a href="branch.php">Standard</a></li>
                      
                      
                            <li class="active">  <a href="staff.php">Staff</a></li>
                       
                       
                            <li> <a href="feedback.php">FeedBack</a></li>
                       
                        
                            <li> <a href="admin/index.php">Admin Panel</a></li>
                       
                        
                            <li><a href="contact.php">Contact Us</a></li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="top-content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="login-section">
                        <div class="col-md-4 col-sm-12">
                            <div class="form1">
                                <form action="/action_page.php">
                                    <h4 class="text-center">Student Login</h4>
                                    <div class="form-group">
                                        <label for="stdUsername">Email:</label>
                                        <input type="text" class="form-control" id="stdUsername" placeholder="Enter Username" name="stdUsername" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="stdPassword">Password:</label>
                                        <input type="password" class="form-control" id="stdPassword" placeholder="Enter password" name="stdPassword" required>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">Login</button>
                                </form>
                            </div>
                            <hr class="hidden-sm">
                            <div class="form2">
                                <form action="/action_page.php">
                                    <h4 class="text-center">Staff Login</h4>
                                    <div class="form-group">
                                        <label for="staffUsername">Email:</label>
                                        <input type="text" class="form-control" id="staffUsername" placeholder="Enter Username" name="staffUsername" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="staffPassword">Password:</label>
                                        <input type="password" class="form-control" id="staffPassword" placeholder="Enter password" name="staffPassword" required>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">Login</button>
                                </form>
                            </div>

                        </div>

                        <div class="col-md-8 col-sm-12">
                             <div class="row">
                           <div class="staff-section">
                               
                                <h4>Staff Report- <span>0</span></h4>
                                <div class="table-responsive">          
                                          <table class="table table-striped table-hover table-bordered" id="tableData">
                                            <thead>
                                              <tr>
                                               
                                                <th>Photo</th>
                                               
                                                <th>Name</th>
                                                
                                                 <th>Mobile</th>
                                                 <th>Qualification</th>
                                                
                                               
                                              </tr>
                                            </thead>
                                            <tbody>
                                                 <tr>
                                               
                                               <td><img src="assets/img/govind.jpg" class="img-responsive" alt="teacher img" style="max-width: 35px;"></td>
                                               <td>Govind Singh</td>
                                              
                                               <td>8853915851</td>
                                               <td>B.Tech</td>
                                               
                                               
                                              </tr>
                                               <tr>
                                               
                                               <td><img src="assets/img/govind.jpg" class="img-responsive" alt="teacher img" style="max-width: 35px;"></td>
                                               <td>Govind Singh</td>
                                              
                                               <td>8853915851</td>
                                               <td>B.Tech</td>
                                               
                                               
                                              </tr>
                                              <tr>
                                               
                                               <td><img src="assets/img/govind.jpg" class="img-responsive" alt="teacher img" style="max-width: 35px;"></td>
                                               <td>Govind Singh</td>
                                              
                                               <td>8853915851</td>
                                               <td>B.Tech</td>
                                               
                                               
                                              </tr>
                                              
                                            </tbody>
                                          </table>
                                          </div>
                            </div>
                           </div>
                        </div>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

  <!--   <script src="assets//lib/js/bootstrap.js"></script> -->
    <script src="assets\lib\js\jquery.js" type="text/javascript"></script>
    <script src="assets\lib\js\bootstrap.min.js" type="text/javascript"></script>
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>  -->
    <script src="assets/lib/js/moment.js" type="text/javascript"></script>
    <script src="assets/lib/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
    <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> 
 -->
    <script src="assets\js\functions.js" type="text/javascript"></script>
</body>

</html>