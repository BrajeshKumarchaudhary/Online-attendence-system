<!DOCTYPE html>
<html lang="en">

<head>
    <title>Feedback Form</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
    <link rel="stylesheet" type="text/css" href="assets/lib/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\font-awesome.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\moonicon.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\build.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/lib/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="assets/lib/css/jquery-ui.css">
   

</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <img src="assets/img/logo.png" class="img-responsive" alt="logo">
                </div>
            </div>
        </div>
    </header>
    <div class="navigation-bar">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                  <ul>
                        
                            <li ><a href="index.php">Home</a></li>
                       
                       
                            <li > <a href="branch.php">Standard</a></li>
                      
                      
                            <li>  <a href="staff.php">Staff</a></li>
                       
                       
                            <li class="active"> <a href="feedback.php">FeedBack</a></li>
                       
                        
                            <li> <a href="admin/index.php">Admin Panel</a></li>
                       
                        
                            <li><a href="contact.php">Contact Us</a></li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="top-content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="login-section">
                       <div class="col-md-4 col-sm-12">
                            <div class="form1">
                                <form action="/action_page.php">
                                    <h4 class="text-center">Student Login</h4>
                                    <div class="form-group">
                                        <label for="stdUsername">Username:</label>
                                        <input type="text" class="form-control" id="stdUsername" placeholder="Enter Username" name="stdUsername" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="stdPassword">Password:</label>
                                        <input type="password" class="form-control" id="stdPassword" placeholder="Enter password" name="stdPassword" required>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">Login</button>
                                </form>
                            </div>
                            <hr class="hidden-sm">
                            <div class="form2">
                                <form action="/action_page.php">
                                    <h4 class="text-center">Staff Login</h4>
                                    <div class="form-group">
                                        <label for="staffUsername">Username:</label>
                                        <input type="text" class="form-control" id="staffUsername" placeholder="Enter Username" name="staffUsername" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="staffPassword">Password:</label>
                                        <input type="password" class="form-control" id="staffPassword" placeholder="Enter password" name="staffPassword" required>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">Login</button>
                                </form>
                            </div>

                        </div>

                        <div class="col-md-8 col-sm-12">
                             <div class="row">
                           <div class="feedback-section">
                               
                                <h4>FeedBack Form</h4>
                                <div class="feedback-form">
                                <form action="">
                                   
                                    <div class="form-group">
                                        <label for="name">Enter Name:</label>
                                        <input type="text" class="form-control" id="name" placeholder="Enter name" name="name" onkeypress="return blockSpecialChar(event)" onchange="return trim(this)" required>

                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email:</label>
                                        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">Phone:</label>
                                        <input type="text" class="form-control" id="phone" placeholder="Enter phone" name="phone" required><span id="errmsg" style="color: #FF0000;"></span>
                                    </div>
                                     <div class="form-group">
                                            <label for="feedback">Feedback:</label>
                                             <textarea class="form-control" rows="5" id="feedback" name="feedback" required></textarea>
                                    </div>
                                    
                                    
                                    <button type="submit" id="sendFeedback" class="btn btn-success" onsubmit="return myFunction()">Send Feedback</button>
                                </form>
                            </div>
                            </div>
                           </div>
                        </div>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets\lib\js\jquery.js" type="text/javascript"></script>
    <script src="assets//lib/js/bootstrap.js"></script>
    
    <script src="assets\lib\js\bootstrap.min.js" type="text/javascript"></script>
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>  -->
    <script src="assets/lib/js/moment.js" type="text/javascript"></script>
    <script src="assets/lib/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
    <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> 
 -->
    <script src="assets\js\functions.js" type="text/javascript"></script>
     <script type="text/javascript">
     $(document).ready(function () {

  
  $("#phone").keypress(function (e) {
   if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        $("#errmsg").html("Digits Only").show().fadeOut("slow");
               return false;
        }
    });
   $("#phone").on("click",function(){
       document.getElementById("phone").maxLength = "10";
   
   });
   
});
      function blockSpecialChar(e) {
            var k = e.keyCode;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 32);
        }
       function trim(el) {
            el.value = el.value.
            replace(/(^\s*)|(\s*$)/gi, "").
            replace(/[ ]{2,}/gi, " "). 
            replace(/\n +/, "\n");
            return;
        }
        


</script>
<script type="text/javascript">
    $(document).ready(function(e){
    $('#sendFeedback').click(function() {
        var sEmail = $('#email').val();
        if ($.trim(sEmail).length == 0) {
            alert('Enter email');
            e.preventDefault();
        }
        if (validateEmail(sEmail)) {
            /*alert('Email is valid');*/
        }
        else {
            alert('Invalid Email Address');
            e.preventDefault();
        }
    });
});
function validateEmail(sEmail) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(sEmail)) {
        return true;
    }
    else {
        return false;
    }
}
function myFunction()
{
    var email=document.getElementById("email").value;
    if (email=="pec.govind@gmail.com") {
            alert("email is true");
    }
    else
    {
        alert("email is false");
    }
}
</script>
</body>

</html>