<!DOCTYPE html>
<html lang="en">

<head>
    <title>Student Attendance</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/moonicon.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/build.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="../assets/lib/css/jquery-ui.css">
   
  <style type="text/css">
    .absentBg{background: red;color: #fff;border: none;}
  </style>

</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-sm-6 hidden-xs">
                    <div class="header-border">
                        <img src="../assets/img/logo.png" class="img-responsive" alt="logo">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="text-right" style="font-size: 25px;color: #000;">
                        <figure><img src="../assets/img/teacher.png" class="img-responsive" alt="Teacher Image" style="max-width: 65px;">
                            <figcaption>Welcome <span>Meera</span></figcaption>
                        </figure>
                    </div>
                </div>

            </div>
        </div>
        </div>
    </header>

    <div class="mainDiv">
        <div class="container">
            <div class="row">

                <div class="menuFields">
                    <div class="col-sm-12">

                        <nav class="navbar navbar-default navbar-static-top">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="#" style="display: none;">Staff Menu</a>
                            </div>

                            <div id="navbar" class="navbar-collapse collapse">
                                <ul class="nav navbar-nav">

                                    <li><a href="index.php">Home</a></li>

                                    <li><a href="addStudent.php">ADD Student</a></li>

                                    <li> <a href="stdReport.php">Student Report</a></li>

                                    <li class="active"> <a href="stdAttendance.php">Attendance</a></li>

                                    <li><a href="attendanceReport.php">Attendance Report</a></li>

                                    <li><a href="advanceReport.php">Advance Reports</a></li>

                                    <li><a href="stdComplain.php">Complain</a></li>

                                    <li><a href="leave.php">Leave</a></li>

                                   <li><a href="changePassword.php">Change Password</a></li>

                                     <li><a href="logout.php">LogOut</a></li>

                                </ul>
                            </div>
                        </nav>
                    </div>

                    <div class="col-sm-12">

                        <div class="menuFieldContent">

                            <h4>Students Attendance<span></span></h4>
                           
                            <form class="staffData">

                                <div class="row">
                                  <div class="col-sm-4">
                                        <div>
                                            <div class="form-group">
                                                <div class="row">

                                                    <div id="datetimepicker12"></div>

                                                </div>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="courseName">Branch Name</label>
                                                    <select name="courseName" id="courseName" class="form-control" required>
                                                        <option value="">Select Branch</option>
                                                        <option>Computer Science &amp; Engineering</option>

                                                    </select>

                                                </div>
                                                <div class="form-group">
                                                    <button type="submit" value="ADD Attendance" class="btn btn-primary">ADD Attendance</button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        
                                        <div class="row">
                                            <div class="col-sm-12 table-responsive" style="height: 350px;overflow: scroll;width: 99%;">
                                                <table class="table table-striped table-hover table-bordered" id="tableData">
                                                    <thead>
                                                        <tr>

                                                            <th>ROllNO</th>
                                                            <th>Name</th>
                                                            <th>Attendance</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option class="present">Present</option>
                                                                        <option class="absent">Absent</option>
                                                                        <option class="leave">Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control attendanceStatus" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>
                                                         <tr>

                                                            <td>1441910036</td>
                                                            <td>Govind Singh</td>
                                                            <td>
                                                                <div class="form-group">

                                                                    <select name="attendanceStatus" id="attendanceStatus" class="form-control" required>
                                                                        <option>Please Select</option>
                                                                        <option>Present</option>
                                                                        <option>Absent</option>
                                                                        <option>Leave</option>
                                                                    </select>

                                                                    </select>

                                                                </div>
                                                            </td>

                                                        </tr>


                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                    

                                </div>

                            </form>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- <script src="../assets/lib/js/bootstrap.js"></script> -->
    <script src="../assets/lib/js/jquery.js" type="text/javascript"></script>
    <script src="../assets/lib/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../assets/lib/js/moment.js" type="text/javascript"></script>
    <script src="../assets/lib/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
    <script src="../assets/js/functions.js" type="text/javascript"></script>
    <!--  <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> -->
    <script type="text/javascript">
        $(function() {
            $('#datetimepicker12').datetimepicker({
                format: 'DD/MM/YY',
                inline: true,
                sideBySide: true

            });
        });
    </script>
     <script>
  $( function() {
    $( ".absent" ).on( "click", function() {
      $( ".attendanceStatus" ).addClass("absentBg");
    });
 
   
  } );
  </script>

</body>

</html>