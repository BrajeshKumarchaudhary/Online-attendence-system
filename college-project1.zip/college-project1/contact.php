<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
    <link rel="stylesheet" type="text/css" href="assets/lib/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\font-awesome.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\moonicon.css">
    <link rel="stylesheet" type="text/css" href="assets\lib\css\build.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/lib/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="assets/lib/css/jquery-ui.css">

</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <img src="assets/img/logo.png" class="img-responsive" alt="logo">
                </div>
            </div>
        </div>
    </header>
    <div class="navigation-bar">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <ul>
                        
                            <li ><a href="index.php">Home</a></li>
                       
                       
                            <li > <a href="branch.php">Standard</a></li>
                      
                      
                            <li>  <a href="staff.php">Staff</a></li>
                       
                       
                            <li> <a href="feedback.php">FeedBack</a></li>
                       
                        
                            <li> <a href="admin/index.php">Admin Panel</a></li>
                       
                        
                            <li class="active"><a href="contact.php">Contact Us</a></li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="top-content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="login-section">
                       <div class="col-md-4 col-sm-12">
                            <div class="form1">
                                <form action="/action_page.php">
                                    <h4 class="text-center">Student Login</h4>
                                    <div class="form-group">
                                        <label for="stdUsername">Email:</label>
                                        <input type="text" class="form-control" id="stdUsername" placeholder="Enter Username" name="stdUsername" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="stdPassword">Password:</label>
                                        <input type="password" class="form-control" id="stdPassword" placeholder="Enter password" name="stdPassword" required>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">Login</button>
                                </form>
                            </div>
                            <hr class="hidden-sm">
                            <div class="form2">
                                <form action="/action_page.php">
                                    <h4 class="text-center">Staff Login</h4>
                                    <div class="form-group">
                                        <label for="staffUsername">Email:</label>
                                        <input type="text" class="form-control" id="staffUsername" placeholder="Enter Username" name="staffUsername" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="staffPassword">Password:</label>
                                        <input type="password" class="form-control" id="staffPassword" placeholder="Enter password" name="staffPassword" required>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-success">Login</button>
                                </form>
                            </div>

                        </div>

                        <div class="col-md-8 col-sm-12">
                             <div class="row">
                           <div class="contact-content">
                               
                                <h4>Contact Us</h4>
                               <map> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114369.70424329562!2d79.95341295581683!3d26.389466983355693!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399db430901d80d9%3A0xf5337f63fa73a4fe!2sPrabhat+Engineering+College!5e0!3m2!1sen!2sin!4v1520597375631" width="100%" height="300" frameborder="0" style="border:0" id="collegeMap" allowfullscreen></iframe></map>
                                <address>
                                <h3>College Address</h3>
                                <p>NH-2 Rania Bara</p>
                                <p>Kanpur Dehat 209304(U.P)</p>
                                <p>Mobile: 8853915851</p>
                                <p>Email: pec.govind@gmail.com</p>
                                </address>
                            </div>
                           </div>
                        </div>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- <script src="assets//lib/js/bootstrap.js"></script> -->
    <script src="assets\lib\js\jquery.js" type="text/javascript"></script>
    <script src="assets\lib\js\bootstrap.min.js" type="text/javascript"></script>
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>  -->
    <script src="assets/lib/js/moment.js" type="text/javascript"></script>
    <script src="assets/lib/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
    <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> 
 -->
    <script src="assets\js\functions.js" type="text/javascript"></script>
</body>

</html>