<?php
$username='root';
$password='';
$dbnamme='sport';
$host='localhost';

?>