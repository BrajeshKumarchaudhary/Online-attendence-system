<!DOCTYPE html>
<html lang="en">

<head>
    <title>Student Attendance</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/moonicon.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/build.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="../assets/lib/css/jquery-ui.css">

</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-sm-6 hidden-xs">
                    <div class="header-border">
                        <img src="../assets/img/logo.png" class="img-responsive" alt="logo">
                    </div>
                </div>
                <div class="col-sm-6 col-xs-12">
                    <div class="text-right" style="font-size: 25px;color: #000;">
                        <figure><img src="../assets/img/teacher.png" class="img-responsive" alt="Teacher Image" style="max-width: 65px;">
                            <figcaption>Welcome <span>Meera</span></figcaption>
                        </figure>
                    </div>
                </div>

            </div>
        </div>
        </div>
    </header>

    <div class="mainDiv">
        <div class="container">
            <div class="row">

                <div class="menuFields stdSection">
                    <div class="col-sm-12">

                        <nav class="navbar navbar-default navbar-static-top">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="#" style="display: none;">Student Menu</a>
                            </div>

                            <div id="navbar" class="navbar-collapse collapse">
                                <ul class="nav navbar-nav">

                                    <li><a href="index.php">Home</a></li>

                                  

                                    <li class="active"> <a href="stdAttendance.php">Attendance</a></li>

                                   

                                    <li ><a href="stdComplain.php">Complain</a></li>

                                    <li ><a href="leave.php">Leave</a></li>

                                   <li><a href="changePassword.php">Change Password</a></li>

                                    <li><a href="logout.php">LogOut</a></li>

                                </ul>
                            </div>
                        </nav>
                    </div>

                    <div class="col-sm-12">

                        <div class="menuFieldContent">
                            <h4>Attendance<span></span></h4>
                                <div class="stdAttendance">
                                    <form>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <select class="form-control">
                                                    <option>month</option>
                                                    <option>1</option>
                                                    <option>2</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                               <button type="submit" class="btn btn-primary" class="form-control">show Report</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                 <div class="table-responsive" style="margin-top: 20px;width: 100%;">
                                <table class="table table-striped table-hover table-bordered newLeave" id="tableData">
                                    <thead>
                                        <tr>
                                            
                                            <th>Date</th>
                                          
                                            <th>Attendance</th>
                                            <th>Attendance By</th>
                                           

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                           
                                            <td>26/02/2018</td>
                                          
                                            <td>present</td>
                                            <td>Meera Kumari</td>
                                           

                                        </tr>
                                     

                                    </tbody>
                                </table>
                            </div>

                                
                               
                                

                            </div>

                           
                           

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   <!-- <script src="../assets/lib/js/bootstrap.js"></script> -->
    <script src="../assets/lib/js/jquery.js" type="text/javascript"></script>
    <script src="../assets/lib/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../assets/lib/js/moment.js" type="text/javascript"></script>
    <script src="../assets/lib/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
    <script src="../assets/js/functions.js" type="text/javascript"></script>
    <script src="../assets/lib/js/jquery-ui.js" type="text/javascript">
    </script>
    <!--  <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> -->
    <script type="text/javascript">
        $(document).ready(function() {

            load_json_data('country');

            function load_json_data(id, parent_id) {
                var html_code = '';
                $.getJSON('country_state_city.json', function(data) {

                    html_code += '<option value="">Select ' + id + '</option>';

                    $.each(data.slice().sort(nameSort), function(key, value) {
                        if (id == 'country') {
                            if (value.parent_id == '0') {
                                html_code += '<option value="' + value.id + '">' + value.name + '</option>';
                            }
                        } else {
                            if (value.parent_id == parent_id) {
                                html_code += '<option value="' + value.id + '">' + value.name + '</option>';
                            }
                        }
                    });
                    $('#' + id).html(html_code);
                });
            }
            $(document).on('change', '#country', function() {
                var country_id = $(this).val();
                if (country_id != '') {
                    load_json_data('state', country_id);
                } else {
                    $('#state').html('<option value="">Select State</option>');
                    $('#district').html('<option value="">Select District</option>');
                }
            });
            $(document).on('change', '#state', function() {
                var state_id = $(this).val();
                if (state_id != '') {
                    load_json_data('district', state_id);
                } else {
                    $('#district').html('<option value="">Select District</option>');
                }
            });
        });

        function nameSort(a, b) {
            if (b.name < a.name) return 1;
            if (b.name > a.name) return -1;
            else return 0;
        }
    </script>
     <script>
        $(function() {
            var names = [
                "Exam Reciept",
                "About Exam",
                "Annual Function",
                
                "other"

            ];
            $("#complainSubject").autocomplete({
                source: names
            });

        });
   
   
    </script>
</body>

</html>