<?php 
session_start();
if ($_SESSION["login_user"]==true) {
    
}
else
{

header("location:index.php");
}

 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/moonicon.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/build.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="../assets/lib/css/jquery-ui.css">

    

</head>

<body>
    <header>
        <div class="container">
            <div class="row">
               <div class="col-sm-6 hidden-xs">
                    <div class="header-border">
                        <img src="../assets/img/logo.png" class="img-responsive" alt="logo">
                    </div>
                  </div>
                   <div class="col-sm-6 col-xs-12">
                        <div class="text-right" style="font-size: 25px;color: #000;"><?php echo "Welcome:"."   ".$_SESSION["login_user"]; ?></div>
                </div>
               
            </div>
        </div>
    </header>

    <div class="mainDiv">
        <div class="container">
            <div class="row">
              
                    <div class="menuFields">
                       <div class="col-sm-12">

                            <nav class="navbar navbar-default navbar-static-top">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                    <a class="navbar-brand" href="#" style="display: none;">ADMIN MENU</a>
                                </div>

                                <div id="navbar" class="navbar-collapse collapse">
                                    <ul class="nav navbar-nav">

                                        <li><a href="home.php">Home</a></li>

                                        <li> <a href="addCourse.php">ADD Course </a></li>

                                        <li> <a href="addBranch.php">ADD Branch</a></li>

                                        <li ><a href="addStaff.php">ADD Staff</a></li>

                                        <li> <a href="staffReport.php">Staff Report</a></li>

                                        <li> <a href="complain.php">Complain</a> </li>

                                         <li><a href="leave.php">Leave</a></li>

                                        <li class="active"><a href="stdReport.php">Student Reports</a></li>

                                         <li><a href="feedback.php">Feedback</a> </li>

                                        <li> <a href="logout.php">LogOut</a></li>

                                    </ul>
                                </div>
                            </nav>
                        </div>

                      

                        <div class="col-sm-12">
                          
                             <div class="menuFieldContent">
                                 <h4>Student Report</h4>

                                    
                               
                            <form class="staffData" style="padding: 20px 0px;">

                               <div class="col-sm-3" >
                                  <div class="form-group">
                                        <label for="courseName">Course Name</label>
                                        <select name="courseName" id="courseName" class="form-control" required>
                                            <option value="">Select Course</option>
                                            <option>B.Tech</option>
                                            <option>Polytechnic</option>
                                            <option>MBA</option>


                                        </select>

                                    </div>
                               </div>
                               
                                <div class="col-sm-3">
                                    <div class="form-group">
                                        <label for="branchName">Branch Name</label>
                                        <select name="branchName" id="branchName" class="form-control" required>
                                            <option value="">Select Branch</option>
                                            <option>Computer Science &amp; Engineering</option>
                                            <option>Civil</option>
                                            <option>Mechanical</option>
                                            <option>Electronics</option>
                                            <option>Electrical</option>

                                        </select>

                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <label for="searchStudent">Student Name</label>
                                        <input type="search" name="searchStudent" id="searchStudent" class="form-control" required>

                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="form-group">

                                        <button type="submit" value="submit" id="showDetail" class="btn btn-primary" style="margin-top: 25px;" >Show Detail</button>
                                        <img src="../assets/img/govind.jpg" class="img-responsive stdImg" alt="Image">

                                    </div>
                                </div>

                            </form>
                              <div class="stdData">
                                    <div class="col-sm-4">

                                        <div class="form-group">
                                            <label for="stdRollNO">Student RollNo</label>
                                            <input type="text" class="form-control" placeholder="Enter  Student RollNo" id="stdRollNO" required>
                                           

                                        </div>
                                    </div>

                                    <div class="col-sm-4">

                                        <div class="form-group">
                                            <label for="stdName">Student Name</label>
                                            <input type="text" class="form-control" placeholder="Enter Student Name" id="stdName" required>

                                        </div>
                                    </div>
                                    <div class="col-sm-4">

                                        <div class="form-group">
                                            <label for="fatherName">Father Name</label>
                                            <input type="text" class="form-control" placeholder="Enter Father Name" id="fatherName" required>

                                        </div>
                                    </div>
                                    <div class="col-sm-4">

                                        <div class="form-group">
                                            <label for="phone">Mobile</label>
                                            <input type="text" class="form-control" placeholder="Enter Mobile No" id="phone" required>

                                        </div>
                                    </div>
                                     <div class="col-sm-4">

                                        <div class="form-group">
                                            <label for="stdEmail">Email</label>
                                            <input type="email" class="form-control" placeholder="Enter Email" id="stdEmail" required>

                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="stdDob">Date of Birth</label>

                                            <div class="dob">
                                                <input id="stdDob" type="date" class="form-control" name="stdDob" required>
                                                <span class="glyphicon glyphicon-calendar"></span></div>
                                        </div>

                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="gender">Gender</label>
                                            <select class="form-control" id="gender">
                                                <option>Male</option>
                                                <option>Female</option>

                                            </select>

                                        </div>
                                    </div>

                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="country">Country</label>
                                            <select name="country" id="country" class="form-control">
                                                <option value="">Select country</option>
                                            </select>

                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="state">State</label>
                                            <select name="state" id="state" class="form-control">
                                                <option value="">Select State</option>
                                            </select>

                                        </div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="form-group">
                                            <label for="district">District</label>
                                            <select name="district" id="district" class="form-control">
                                                <option value="">Select District</option>
                                            </select>

                                        </div>
                                    </div>

                                    <div class="col-sm-4">

                                        <div class="form-group">
                                            <label for="pinCode">Pincode</label>
                                            <input type="text" class="form-control" placeholder="Enter PinCode" id="pinCode" required>

                                        </div>
                                    </div>

                                    <div class="col-sm-4">

                                        <div class="form-group">
                                            <label for="userName">Username</label>
                                            <input type="text" class="form-control" placeholder="Enter User Name" id="userName" required>

                                        </div>
                                    </div>
                                    <div class="col-sm-4">

                                        <div class="form-group">
                                            <label for="userPassword">Password</label>
                                            <input type="text" class="form-control" placeholder="Enter User Password" id="userPassword" required>

                                        </div>
                                    </div>
                                  
                                   
                                   
                                </div>
                           
                               
                                   
                                 

                              
                                    
                               

                            </div>

                        </div>

                    </div>
               
            </div>
        </div>
    </div>

    <!-- <script src="../assets/lib/js/bootstrap.js"></script> -->
    <script src="../assets/lib/js/jquery.js" type="text/javascript"></script>
    <script src="../assets/lib/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../assets/lib/js/moment.js" type="text/javascript"></script>
    <script src="../assets/lib/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
    <script src="../assets/js/functions.js" type="text/javascript"></script>
      <script src="../assets/lib/js/jquery-1.12.4.js"></script>
    <script src="../assets/lib/js/jquery-ui.js"></script>
   <!--  <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> -->
    <script>
$(document).ready(function(){

 load_json_data('country');

 function load_json_data(id, parent_id)
 {
  var html_code = '';
  $.getJSON('country_state_city.json', function(data){

   html_code += '<option value="">Select '+id+'</option>';
  
   $.each(data.slice().sort(nameSort), function(key, value){
    if(id == 'country')
    {
     if(value.parent_id == '0')
     {
      html_code += '<option value="'+value.id+'">'+value.name+'</option>';
     }
    }
    else
    {
     if(value.parent_id == parent_id)
     {
      html_code += '<option value="'+value.id+'">'+value.name+'</option>';
      }
    }
   });
   $('#'+id).html(html_code);
  });

 }

 $(document).on('change', '#country', function(){
  var country_id = $(this).val();
  if(country_id != '')
  {
   load_json_data('state', country_id);
  }
  else
  {
   $('#state').html('<option value="">Select State</option>');
   $('#district').html('<option value="">Select District</option>');
  }
 });
 $(document).on('change', '#state', function(){
  var state_id = $(this).val();
  if(state_id != '')
  {
   load_json_data('district', state_id);
  }
  else
  {
   $('#district').html('<option value="">Select District</option>');
  }
 });
});
function nameSort(a,b){
  if(b.name < a.name) return 1;
  if(b.name > a.name) return -1;
  else return 0;  
}
</script>
  <script type="text/javascript">
                                                $(".stdData input,.stdData select").prop('disabled', true);
                                            </script>
    <script>
        $(function() {
            var names = [
                "Govind",
                "Maneesh",
                "Brajesh",
                "Ankit",
                "Rohit",
                "Anwar",
                "Sandeep",
                "Soni"

            ];
            $("#searchStudent").autocomplete({
                source: names
            });

        });
   
   
    </script>

</body>

</html>