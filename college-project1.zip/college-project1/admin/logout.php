
<?php
session_start();
session_destroy();
mysqli_close($db);
header("Location: index.php");

?>