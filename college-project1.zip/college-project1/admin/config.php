<?php
	$hostname='localhost';
	$user = 'root';
	$password ='';
	$mysql_database = 'college';
	$db = mysqli_connect($hostname, $user, $password,$mysql_database);
	mysqli_select_db($db,"college");
	
?>