<!DOCTYPE html>
<html lang="en">

<head>
    <title>Admin Login Page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/font-awesome.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/moonicon.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/build.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="../assets/lib/css/jquery-ui.css">

</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 text-center">
                    <img src="../assets/img/logo.png" class="img-responsive" alt="logo" style="display: inline-block;">
                </div>
            </div>
        </div>
    </header>

    <div class="admin-login-page">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="login-section">

                        <div class="admin-login-form">
                            <form  method="post" name="">
                                <h4 class="text-center">Admin Login Panel</h4>
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <input type="text" class="form-control" id="username" placeholder="Enter username" name="username" required>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password:</label>
                                    <input type="password" class="form-control" id="password" placeholder="Enter password" name="password" required>
                                </div>

                                <button type="submit" class="btn btn-success" name="submit">Login</button>
                               <p class="text-center"> <a href="../index.php">Back to Home</a></p>
                            </form>

                        </div>

                    </div>
                </div>

            </div>

        </div>
    </div>
    <?php
    if (isset($_POST['submit']))
        {     
    include("config.php");
    session_start();
    $username=$_POST['username'];
    $password=$_POST['password'];
    $_SESSION['login_user']=$username; 
    $query = mysqli_query($db,"SELECT username FROM adminlogindetail WHERE username='$username' and password='$password'");
     if (mysqli_num_rows($query) != 0)
    {
     echo "<script language='javascript' type='text/javascript'> location.href='home.php' </script>";   
      }
      else
      {
    echo "<script type='text/javascript'>alert('Please Enter Valid Username and Password')</script>";
    }
    }
    ?>

    <!-- <script src="../assets/lib/js/bootstrap.js"></script> -->
    <script src="../assets\lib\js\jquery.js" type="text/javascript"></script>
    <script src="../assets/lib/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>  -->
    <script src="../assets/lib/js/moment.js" type="text/javascript"></script>
    <script src="../assets/lib/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
    <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> 
 -->
    <script src="../assets\js\functions.js" type="text/javascript"></script>
</body>

</html>