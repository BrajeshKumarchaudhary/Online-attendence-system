<?php 
session_start();
if ($_SESSION["login_user"]==true) {
}
else
{
header("location:index.php");
}

 ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
        <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../assets/lib/css/font-awesome.css">
        <link rel="stylesheet" type="text/css" href="../assets/lib/css/moonicon.css">
        <link rel="stylesheet" type="text/css" href="../assets/lib/css/build.css">
        <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
        <link rel="stylesheet" type="text/css" href="../assets/lib/css/bootstrap-datetimepicker.min.css">
        <link rel="stylesheet" href="../assets/lib/css/jquery-ui.css">

    </head>

    <body>
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 hidden-xs">
                        <div class="header-border">
                            <img src="../assets/img/logo.png" class="img-responsive" alt="logo">
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-12">
                        <div class="text-right" style="font-size: 25px;color: #000;">
                            <?php echo "Welcome:"."   ".$_SESSION["login_user"]; ?>
                        </div>
                    </div>

                </div>
            </div>
        </header>

        <div class="mainDiv">
            <div class="container">
                <div class="row">

                    <div class="menuFields">
                        <div class="col-sm-12">

                            <nav class="navbar navbar-default navbar-static-top">
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                    <a class="navbar-brand" href="#" style="display: none;">ADMIN MENU</a>
                                </div>

                                <div id="navbar" class="navbar-collapse collapse">
                                    <ul class="nav navbar-nav">

                                        <li><a href="home.php">Home</a></li>

                                        <li class="active"> <a href="addCourse.php">ADD Course </a></li>

                                        <li> <a href="addBranch.php">ADD Branch</a></li>

                                        <li><a href="addStaff.php">ADD Staff</a></li>

                                        <li> <a href="staffReport.php">Staff Report</a></li>

                                        <li> <a href="complain.php">Complain</a> </li>

                                         <li><a href="leave.php">Leave</a></li>

                                         <li><a href="stdReport.php">Student Reports</a></li>

                                        <li><a href="feedback.php">Feedback</a> </li>

                                        <li> <a href="logout.php">LogOut</a></li>

                                    </ul>
                                </div>
                            </nav>
                        </div>

                        <div class="col-sm-12">

                            <div class="menuFieldContent">

                                <h4>Course Detail<span><a href="#courseModel"><button type="button" class=" btn-success" data-toggle="modal" data-target="#courseModel">ADD Course</button></a></span></h4>

                                <!-- Course Detail Table  -->
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover table-bordered" id="tableData">
                                        <thead>
                                            <tr>
                                                <th>&nbsp;</th>
                                                <th>Course Name</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="editDeleteButton">
                                                        <button class="btn btn-primary edit">Edit</button>
                                                        <button class="btn btn-danger delete">Delete</button>
                                                    </div>
                                                </td>
                                                <td>B. Tech</td>

                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="editDeleteButton">
                                                        <button class="btn btn-primary edit">Edit</button>
                                                        <button class="btn btn-danger delete">Delete</button>
                                                    </div>
                                                </td>

                                                <td>Polytechnic (Diploma)</td>

                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="editDeleteButton">
                                                        <button class="btn btn-primary edit">Edit</button>
                                                        <button class="btn btn-danger delete">Delete</button>
                                                    </div>
                                                </td>

                                                <td>MBA</td>

                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Modal -->
                                <div class="modal fade" id="courseModel" role="dialog">
                                    <div class="modal-dialog">

                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">

                                                <h4 class="modal-title">ADD Course</h4>
                                            </div>
                                            <div class="modal-body">
                                                <form id="CourseAddForm">
                                                    <div class="form-group">
                                                        <label for="courseName">Course Name:</label>
                                                        <input type="text" class="form-control" placeholder="Enter Course Name" id="courseName" required>
                                                        <button type="submit" class="btn btn-success">ADD</button>
                                                    </div>

                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>

        <script src="../assets\lib\js\jquery.js" type="text/javascript"></script>
        <!--  <script src="../assets/lib/js/bootstrap.js"></script> -->

        <script src="../assets/lib/js/bootstrap.min.js" type="text/javascript"></script>
        <!-- <script src="https://code.jquery.com/jquery-1.12.4.js"></script>  -->
        <script src="../assets/lib/js/moment.js" type="text/javascript"></script>
        <script src="../assets/lib/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
        <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> 
 -->
        <script src="../assets\js\functions.js" type="text/javascript"></script>
    </body>

    </html>